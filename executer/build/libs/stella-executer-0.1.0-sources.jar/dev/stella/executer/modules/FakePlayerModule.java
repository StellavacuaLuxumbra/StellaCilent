package dev.stella.executer.modules;

import com.mojang.authlib.GameProfile;
import dev.stella.executer.gui.Category;
import dev.stella.executer.gui.setting.*;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_3469;
import net.minecraft.class_3532;
import net.minecraft.class_634;
import net.minecraft.class_746;

public class FakePlayerModule extends ModBase {
    private class_746 fakePlayer = null;

    public FakePlayerModule() {
        super("FakePlayer", Category.MISC, 27);
        add(new SliderSetting("Health", 20.0, 1.0, 40.0, 0.5, ""));
        add(new BooleanSetting("CopyInventory", false));
        add(new SliderSetting("Distance", 2.0, 0.5, 5.0, 0.5, "blocks"));
    }

    @Override
    public void onEnable() {
        spawnFakePlayer();
    }

    @Override
    public void onDisable() {
        removeFakePlayer();
    }

    private void spawnFakePlayer() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        removeFakePlayer();

        float yaw = mc.field_1724.method_36454();
        var distSetting = (SliderSetting) getSetting("Distance");
        float dist = distSetting != null ? (float) distSetting.getValue() : 2.0f;

        double spawnX = mc.field_1724.method_23317() - class_3532.method_15374(yaw * 0.017453292F) * dist;
        double spawnZ = mc.field_1724.method_23321() + class_3532.method_15362(yaw * 0.017453292F) * dist;

        var profile = new com.mojang.authlib.GameProfile(UUID.randomUUID(), "FakePlayer");

        class_634 netHandler = mc.method_1562();
        if (netHandler == null) return;

        fakePlayer = new class_746(
                mc,
                mc.field_1687,
                netHandler,
                new class_3469(),
                new class_299(),
                false,
                false
        );

        fakePlayer.method_5725(
                fakePlayer.method_24515().method_49637(spawnX, mc.field_1724.method_23318(), spawnZ),
                yaw,
                mc.field_1724.method_36455()
        );

        var healthSetting = (SliderSetting) getSetting("Health");
        float health = healthSetting != null ? (float) healthSetting.getValue() : 20.0f;
        fakePlayer.method_6033(health);

        var copyInvSetting = (BooleanSetting) getSetting("CopyInventory");
        if (copyInvSetting != null && copyInvSetting.getValue()) {
            for (int i = 0; i < 9; i++) {
                fakePlayer.method_31548().method_5447(i, mc.field_1724.method_31548().method_5438(i).method_7972());
            }
        }

        mc.field_1687.method_53875(fakePlayer);
    }

    private void removeFakePlayer() {
        class_310 mc = class_310.method_1551();
        if (fakePlayer != null && mc.field_1687 != null) {
            mc.field_1687.method_2945(fakePlayer.method_5628(), class_1297.class_5529.field_26999);
            fakePlayer = null;
        }
    }

    public class_746 getFakePlayer() {
        return fakePlayer;
    }
}
