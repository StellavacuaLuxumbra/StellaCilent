package dev.stella.executer.modules;

import dev.stella.executer.gui.Module;
import dev.stella.executer.gui.ModuleManager;
import dev.stella.executer.gui.setting.BooleanSetting;
import dev.stella.executer.gui.setting.SliderSetting;
import dev.stella.executer.brain.LuaScriptHost;
import dev.stella.executer.protection.RaspProtection;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1738;
import net.minecraft.class_1747;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_9304;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.*;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaTable;

public class ModuleTicker {

    private static ModuleTicker instance;
    private static boolean luaInitialized = false;
    private static boolean raspInitialized = false;

    public static final CopyOnWriteArrayList<class_2596<?>> blinkPackets = new CopyOnWriteArrayList<>();
    private static class_243 blinkStartPos;
    private static float blinkStartYaw, blinkStartPitch;
    public static boolean velocityActive = false;

    public static ModuleTicker getInstance() {
        if (instance == null) instance = new ModuleTicker();
        return instance;
    }

    public void tick(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!raspInitialized) {
            try { RaspProtection.initialize(); raspInitialized = true; } catch (Exception e) {}
        }
        if (RaspProtection.isTampered()) return;
        if (!luaInitialized) {
            try { dev.stella.executer.brain.LuaScriptLoader.loadAll(); luaInitialized = true; } catch (Exception e) {}
        }
        if (LuaScriptHost.isInitialized()) {
            try { LuaScriptHost.tick(mc); } catch (Exception e) {}
        }
        for (Module m : ModuleManager.getInstance().getModules()) {
            if (!m.isEnabled()) continue;
            switch (m.getName()) {
                case "KillAura" -> tickKillAura(mc, m);
                case "ESP" -> tickEsp(mc, m);
                case "Speed" -> tickSpeed(mc, m);
                case "Fly" -> tickFly(mc, m);
                case "Sprint" -> tickSprint(mc, m);
                case "Fullbright" -> tickFullbright(mc, m);
                case "NoFall" -> tickNoFall(mc, m);
                case "Velocity" -> tickVelocity(mc, m);
                case "Step" -> tickStep(mc, m);
                case "FastFall" -> tickFastFall(mc, m);
                case "Criticals" -> tickCriticals(mc, m);
                case "AutoLog" -> tickAutoLog(mc, m);
                case "Timer" -> tickTimer(mc, m);
                case "Freecam" -> tickFreecam(mc, m);
                case "CrystalAura" -> tickCrystalAura(mc, m);
                case "SelfTrap" -> tickSelfTrap(mc, m);
                case "Surround" -> tickSurround(mc, m);
                case "NoSlowDown" -> tickNoSlowDown(mc, m);
                case "AutoTotem" -> tickAutoTotem(mc, m);
                case "ChestStealer" -> tickChestStealer(mc, m);
                case "Scaffold" -> tickScaffold(mc, m);
                case "AutoArmor" -> tickAutoArmor(mc, m);
                case "AutoClicker" -> tickAutoClicker(mc, m);
                case "AimAssist" -> tickAimAssist(mc, m);
                case "FastBreak" -> tickFastBreak(mc, m);
                case "Reach" -> tickReach(mc, m);
                case "Blink" -> tickBlink(mc, m);
                case "AntiHunger" -> tickAntiHunger(mc, m);
                case "FastUse" -> tickFastUse(mc, m);
                case "AutoFish" -> tickAutoFish(mc, m);
            }
        }
        tickBlinkState(mc);
    }

    public static void onSendPacket(class_2596<?> packet, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        Module blinkModule = ModuleManager.getInstance().getModule("Blink");
        if (blinkModule != null && blinkModule.isEnabled()) {
            if (packet instanceof class_2828 || packet instanceof class_2824
                || packet instanceof class_2885 || packet instanceof class_2886
                || packet instanceof class_2879 || packet instanceof class_2846) {
                blinkPackets.add(packet);
                ci.cancel();
            }
        }
    }

    public static void onReceivePacket(class_2596<?> packet) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        Module velocityModule = ModuleManager.getInstance().getModule("Velocity");
        if (velocityModule != null && velocityModule.isEnabled()) {
            if (packet instanceof class_2743 velPacket) {
                if (velPacket.method_11818() == mc.field_1724.method_5628()) {
                    velocityActive = true;
                }
            }
        }
        Module blinkModule = ModuleManager.getInstance().getModule("Blink");
        if (blinkModule != null && blinkModule.isEnabled()) {
            if (packet instanceof class_2708) {
                releaseBlink(mc);
            }
        }
    }

    // ========== Velocity ==========
    private void tickVelocity(class_310 mc, Module m) {
        var hSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Horizontal");
        var vSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Vertical");
        float h = hSetting != null ? (float) hSetting.getValue() / 100f : 0f;
        float v = vSetting != null ? (float) vSetting.getValue() / 100f : 0f;
        if (velocityActive) {
            class_243 vel = mc.field_1724.method_18798();
            mc.field_1724.method_18800(vel.field_1352 * h, vel.field_1351 * v, vel.field_1350 * h);
            velocityActive = false;
        }
    }

    // ========== Criticals ==========
    private void tickCriticals(class_310 mc, Module m) {
        // crit is applied in tickKillAura before attack
    }

    public static void applyCriticals(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        Module m = ModuleManager.getInstance().getModule("Criticals");
        if (m == null || !m.isEnabled()) return;
        if (!mc.field_1724.method_24828()) return;
        if (mc.field_1724.method_5816() || mc.field_1724.method_5771()) return;
        if (mc.field_1724.method_6128()) return;
        double x = mc.field_1724.method_23317();
        double y = mc.field_1724.method_23318();
        double z = mc.field_1724.method_23321();
        mc.method_1562().method_52787(new class_2828.class_2829(x, y + 0.0625, z, false));
        mc.method_1562().method_52787(new class_2828.class_2829(x, y + 0.04535, z, false));
        mc.method_1562().method_52787(new class_2828.class_2829(x, y, z, false));
    }

    // ========== Blink ==========
    private void tickBlink(class_310 mc, Module m) {
        if (blinkStartPos == null) {
            blinkStartPos = mc.field_1724.method_19538();
            blinkStartYaw = mc.field_1724.method_36454();
            blinkStartPitch = mc.field_1724.method_36455();
        }
    }

    private void tickBlinkState(class_310 mc) {
        Module m = ModuleManager.getInstance().getModule("Blink");
        if (m == null || !m.isEnabled()) {
            if (!blinkPackets.isEmpty()) {
                releaseBlink(mc);
            }
            blinkStartPos = null;
            return;
        }
    }

    public static void releaseBlink(class_310 mc) {
        for (class_2596<?> packet : blinkPackets) {
            mc.method_1562().method_52787(packet);
        }
        blinkPackets.clear();
    }

    public static void cancelBlink(class_310 mc) {
        if (blinkStartPos != null) {
            mc.field_1724.method_33574(blinkStartPos);
            mc.field_1724.method_36456(blinkStartYaw);
            mc.field_1724.method_36457(blinkStartPitch);
        }
        blinkPackets.clear();
        blinkStartPos = null;
    }

    public static int getBlinkPacketCount() {
        return blinkPackets.size();
    }

    // ========== NoSlowDown - SunCat style: send slot packets ==========
    private int noSlowDelay = 0;
    private void tickNoSlowDown(class_310 mc, Module m) {
        if (mc.field_1724 == null) return;
        noSlowDelay--;
        if (mc.field_1724.method_6115() && !mc.field_1724.method_3144() && !mc.field_1724.method_6128()) {
            mc.method_1562().method_52787(new class_2868(mc.field_1724.method_31548().field_7545));
            ((dev.stella.executer.mixin.MinecraftClientAccessor) mc).setItemUseCooldown(0);
        }
    }

    // ========== Scaffold - SunCat style ==========
    private class_243 scaffoldVec;
    private void tickScaffold(class_310 mc, Module m) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        int blockSlot = findBlockSlot(mc);
        if (blockSlot == -1) return;
        class_2338 placePos = mc.field_1724.method_24515().method_10074();
        if (!mc.field_1687.method_8320(placePos).method_45474()) return;
        class_2350 side = getPlaceSide(mc, placePos);
        if (side == null) {
            for (class_2350 dir : class_2350.values()) {
                if (dir == class_2350.field_11036) continue;
                class_2338 offset = placePos.method_10093(dir);
                if (mc.field_1687.method_8320(offset).method_26212(mc.field_1687, offset)) {
                    side = dir.method_10153();
                    break;
                }
            }
        }
        if (side == null) return;
        int oldSlot = mc.field_1724.method_31548().field_7545;
        mc.field_1724.method_31548().field_7545 = blockSlot;
        mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, blockSlot < 9 ? blockSlot + 36 : blockSlot, 0, class_1713.field_7791, mc.field_1724);
        class_2338 neighbor = placePos.method_10093(side);
        class_243 hitVec = class_243.method_24953(placePos).method_1019(new class_243(side.method_23955().mul(-0.5f)));
        class_3965 hit = new class_3965(hitVec, side, neighbor, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
        mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, blockSlot < 9 ? blockSlot + 36 : blockSlot, 0, class_1713.field_7791, mc.field_1724);
        var towerSetting = (dev.stella.executer.gui.setting.BooleanSetting) m.getSetting("Tower");
        if (towerSetting != null && towerSetting.getValue() && mc.field_1690.field_1903.method_1434() && mc.field_1724.field_3913.field_3905 == 0 && mc.field_1724.field_3913.field_3907 == 0) {
            mc.field_1724.method_18800(0, 0.42, 0);
        }
    }

    private int findBlockSlot(class_310 mc) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1747) return i;
        }
        return -1;
    }

    private class_2350 getPlaceSide(class_310 mc, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11036) continue;
            class_2338 neighbor = pos.method_10093(dir);
            class_2680 state = mc.field_1687.method_8320(neighbor);
            if (state.method_26212(mc.field_1687, neighbor)) return dir;
        }
        return null;
    }

    // ========== AutoArmor - SunCat protection calc ==========
    private int autoArmorDelay = 0;
    private void tickAutoArmor(class_310 mc, Module m) {
        if (mc.field_1724 == null) return;
        if (mc.field_1755 != null && !(mc.field_1755 instanceof net.minecraft.class_490)) return;
        autoArmorDelay++;
        var delaySetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Delay");
        int delay = delaySetting != null ? (int) delaySetting.getValue() : 3;
        if (autoArmorDelay < delay) return;
        autoArmorDelay = 0;
        for (int armorSlot = 0; armorSlot < 4; armorSlot++) {
            var currentArmor = mc.field_1724.method_31548().method_7372(armorSlot);
            int currentProt = getArmorProtection(currentArmor);
            int bestSlot = -1;
            int bestProt = currentProt;
            for (int i = 0; i < 36; i++) {
                class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                if (stack.method_7960()) continue;
                if (stack.method_7909() instanceof class_1738 armor) {
                    if (armor.method_7685().method_5927() == armorSlot) {
                        int prot = getArmorProtection(stack);
                        if (prot > bestProt) {
                            bestProt = prot;
                            bestSlot = i;
                        }
                    }
                }
            }
            if (bestSlot != -1) {
                mc.field_1761.method_2906(
                    mc.field_1724.field_7498.field_7763,
                    bestSlot < 9 ? bestSlot + 36 : bestSlot,
                    armorSlot + 5,
                    class_1713.field_7791, mc.field_1724
                );
                return;
            }
        }
    }

    private int getArmorProtection(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738)) return -1;
        class_1738 armor = (class_1738) stack.method_7909();
        int prot = armor.method_7687();
        if (stack.method_7942()) {
            var enchants = net.minecraft.class_1890.method_57532(stack);
            for (var entry : enchants.method_57539()) {
                String id = entry.getKey().method_40230().map(k -> k.method_29177().toString()).orElse("");
                int level = entry.getIntValue();
                if (id.contains("protection")) prot += level * 2;
                else if (id.contains("blast_protection")) prot += level;
                else if (id.contains("binding_curse")) return -999;
            }
        }
        return prot;
    }

    // ========== ChestStealer ==========
    private int chestStealerDelay = 0;
    private void tickChestStealer(class_310 mc, Module m) {
        if (mc.field_1755 == null) return;
        var delaySetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Delay");
        int delay = delaySetting != null ? (int) delaySetting.getValue() : 1;
        chestStealerDelay++;
        if (chestStealerDelay < delay) return;
        chestStealerDelay = 0;
        var container = mc.field_1724.field_7512;
        boolean found = false;
        for (int i = 0; i < container.field_7761.size(); i++) {
            class_1799 stack = container.method_7611(i).method_7677();
            if (!stack.method_7960() && isValuable(stack)) {
                mc.field_1761.method_2906(container.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                found = true;
                return;
            }
        }
        if (!found) {
            for (int i = 0; i < container.field_7761.size(); i++) {
                class_1799 stack = container.method_7611(i).method_7677();
                if (!stack.method_7960()) {
                    mc.field_1761.method_2906(container.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                    return;
                }
            }
            mc.field_1724.method_3137();
        }
    }

    private boolean isValuable(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return item == class_1802.field_8288 || item == class_1802.field_8301
            || item == class_1802.field_8634 || item == class_1802.field_8287
            || item == class_1802.field_8367 || item == class_1802.field_8463
            || stack.method_7909() instanceof class_1738;
    }

    // ========== FastFall - SunCat style ==========
    private void tickFastFall(class_310 mc, Module m) {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.method_24828() || mc.field_1724.method_5816() || mc.field_1724.method_5771()) return;
        if (mc.field_1724.method_6128()) return;
        if (mc.field_1724.method_18798().field_1351 >= 0) return;
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351 - 0.5, mc.field_1724.method_18798().field_1350);
    }

    // ========== Freecam - SunCat style ==========
    private void tickFreecam(class_310 mc, Module m) {
        // Freecam requires mixin hooks for camera - simplified version
    }

    // ========== AntiHunger - SunCat style: spoof ground ==========
    private void tickAntiHunger(class_310 mc, Module m) {
        if (mc.field_1724 == null) return;
        var sprintSetting = (dev.stella.executer.gui.setting.BooleanSetting) m.getSetting("Sprint");
        boolean cancelSprint = sprintSetting != null && sprintSetting.getValue();
        if (cancelSprint && mc.field_1724.method_5624()) {
            mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12985));
        }
    }

    // ========== AutoTotem ==========
    private void tickAutoTotem(class_310 mc, Module m) {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.method_6079().method_7909() == class_1802.field_8288) return;
        var healthSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Health");
        float threshold = healthSetting != null ? (float) healthSetting.getValue() : 8.0f;
        if (mc.field_1724.method_6032() > threshold) return;
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8288) {
                mc.field_1761.method_2906(
                    mc.field_1724.field_7498.field_7763,
                    i < 9 ? i + 36 : i, 40, class_1713.field_7791, mc.field_1724);
                return;
            }
        }
    }

    // ========== AutoClicker ==========
    private long autoClickerLastClick = 0;
    private void tickAutoClicker(class_310 mc, Module m) {
        if (mc.field_1755 != null || !mc.field_1690.field_1886.method_1434()) return;
        var minCps = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("MinCPS");
        var maxCps = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("MaxCPS");
        int min = minCps != null ? (int) minCps.getValue() : 10;
        int max = maxCps != null ? (int) maxCps.getValue() : 14;
        int cps = min + (int) (Math.random() * (max - min));
        long delay = 1000L / cps;
        long now = System.currentTimeMillis();
        if (now - autoClickerLastClick < delay) return;
        var hit = mc.field_1765;
        if (hit != null && hit.method_17783() == class_239.class_240.field_1331) {
            class_1297 target = ((class_3966) hit).method_17782();
            if (target instanceof class_1309 le && le.method_5805()) {
                applyCriticals(mc);
                mc.field_1761.method_2918(mc.field_1724, target);
                mc.field_1724.method_6104(class_1268.field_5808);
                autoClickerLastClick = now;
            }
        }
    }

    // ========== AimAssist ==========
    private void tickAimAssist(class_310 mc, Module m) {
        if (mc.field_1755 != null || !mc.field_1690.field_1886.method_1434()) return;
        var speedSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Speed");
        float speed = speedSetting != null ? (float) speedSetting.getValue() : 5.0f;
        var fovSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("FOV");
        float fov = fovSetting != null ? (float) fovSetting.getValue() : 90.0f;
        class_1309 bestTarget = null;
        float bestDist = 6.0f;
        class_238 box = mc.field_1724.method_5829().method_1014(6);
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724 || !(entity instanceof class_1309 le)) continue;
            if (!le.method_5805() || le.method_31481()) continue;
            float dist = mc.field_1724.method_5739(le);
            if (dist < bestDist) {
                bestDist = dist;
                bestTarget = le;
            }
        }
        if (bestTarget == null) return;
        class_243 eye = mc.field_1724.method_33571();
        class_243 targetPos = bestTarget.method_19538().method_1031(0, bestTarget.method_5751() * 0.5, 0);
        double dx = targetPos.field_1352 - eye.field_1352;
        double dy = targetPos.field_1351 - eye.field_1351;
        double dz = targetPos.field_1350 - eye.field_1350;
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        float yawDiff = class_3532.method_15393(targetYaw - mc.field_1724.method_36454());
        float pitchDiff = targetPitch - mc.field_1724.method_36455();
        if (Math.abs(yawDiff) > fov / 2f) return;
        float factor = speed * 0.02f;
        mc.field_1724.method_36456(mc.field_1724.method_36454() + yawDiff * factor);
        mc.field_1724.method_36457(Math.max(-90, Math.min(90, mc.field_1724.method_36455() + pitchDiff * factor)));
    }

    // ========== KillAura ==========
    private void tickKillAura(class_310 mc, Module m) {
        var rangeSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Range");
        float range = rangeSetting != null ? (float) rangeSetting.getValue() : 4.0f;
        var playersOnlySetting = (dev.stella.executer.gui.setting.BooleanSetting) m.getSetting("Players Only");
        boolean playersOnly = playersOnlySetting == null || playersOnlySetting.getValue();
        class_1309 bestTarget = null;
        float bestDist = range;
        class_238 box = mc.field_1724.method_5829().method_1009(range, range, range);
        List<? extends class_1309> entities;
        if (playersOnly) {
            entities = mc.field_1687.method_8390(class_1657.class, box, e -> e != mc.field_1724 && e.method_5805() && !e.method_31481());
        } else {
            entities = mc.field_1687.method_8390(class_1309.class, box, e -> e != mc.field_1724 && e.method_5805() && !e.method_31481());
        }
        for (class_1309 e : entities) {
            float dist = mc.field_1724.method_5739(e);
            if (dist < bestDist) { bestDist = dist; bestTarget = e; }
        }
        if (bestTarget != null) {
            class_243 eye = mc.field_1724.method_33571();
            double dx = bestTarget.method_23317() - eye.field_1352;
            double dy = bestTarget.method_23318() + bestTarget.method_5751() * 0.5 - eye.field_1351;
            double dz = bestTarget.method_23321() - eye.field_1350;
            mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-dx, dz)));
            mc.field_1724.method_36457((float) Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
            Module critMod = ModuleManager.getInstance().getModule("Criticals");
            if (critMod != null && critMod.isEnabled()) applyCriticals(mc);
            mc.field_1761.method_2918(mc.field_1724, bestTarget);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    // ========== Other modules ==========
    private void tickEsp(class_310 mc, Module m) {}
    private void tickSpeed(class_310 mc, Module m) {
        var speedSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Speed");
        float speed = speedSetting != null ? (float) speedSetting.getValue() : 1.5f;
        if (mc.field_1724.field_3913.field_3905 != 0 || mc.field_1724.field_3913.field_3907 != 0) {
            float yawRad = mc.field_1724.method_36454() * 0.017453292f;
            float vx = -class_3532.method_15374(yawRad) * speed * 0.2f;
            float vz = class_3532.method_15362(yawRad) * speed * 0.2f;
            mc.field_1724.method_18800(vx, mc.field_1724.method_18798().field_1351, vz);
        }
    }
    private void tickFly(class_310 mc, Module m) {
        var speedSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Speed");
        float speed = speedSetting != null ? (float) speedSetting.getValue() : 2.0f;
        double vy = 0;
        if (mc.field_1690.field_1903.method_1434()) vy = speed * 0.1;
        else if (mc.field_1690.field_1832.method_1434()) vy = -speed * 0.1;
        mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, vy, mc.field_1724.method_18798().field_1350);
    }
    private void tickSprint(class_310 mc, Module m) {
        if (mc.field_1724.field_3913.field_3905 > 0 && !mc.field_1724.method_5715()) mc.field_1724.method_5728(true);
    }
    private void tickFullbright(class_310 mc, Module m) {
        var b = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Brightness");
        double val = b != null ? b.getValue() : 1.0;
        mc.field_1690.method_42473().method_41748(Math.min(val, 1.0));
    }
    private void tickNoFall(class_310 mc, Module m) {
        if (mc.field_1724.field_6017 > 2.5f) mc.field_1724.method_24830(true);
    }
    private void tickStep(class_310 mc, Module m) {}
    private void tickAutoLog(class_310 mc, Module m) {
        var h = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Health");
        float health = h != null ? (float) h.getValue() : 4.0f;
        if (mc.field_1724.method_6032() <= health) mc.method_18099();
    }
    private void tickTimer(class_310 mc, Module m) {}
    private void tickFastBreak(class_310 mc, Module m) {}
    private void tickReach(class_310 mc, Module m) {}
    private void tickFastUse(class_310 mc, Module m) {
        var multSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Multiplier");
        float mult = multSetting != null ? (float) multSetting.getValue() : 2.0f;
        if (mc.field_1724.method_6115()) ((dev.stella.executer.mixin.MinecraftClientAccessor) mc).setItemUseCooldown(0);
    }
    private void tickAutoFish(class_310 mc, Module m) {
        if (!(mc.field_1724.method_6047().method_7909() instanceof class_1787)) return;
        var hookResult = mc.field_1765;
        if (hookResult != null && hookResult.method_17783() == class_239.class_240.field_1333) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private void tickCrystalAura(class_310 mc, Module m) {
        var rangeSetting = (dev.stella.executer.gui.setting.SliderSetting) m.getSetting("Range");
        float range = rangeSetting != null ? (float) rangeSetting.getValue() : 5.0f;
        class_238 box = mc.field_1724.method_5829().method_1014(range);
        List<class_1511> crystals = mc.field_1687.method_8390(class_1511.class, box, e -> e.method_5805() && !e.method_31481());
        if (crystals.isEmpty()) return;
        class_1511 bestCrystal = null;
        float bestScore = -1;
        for (class_1511 crystal : crystals) {
            float dist = (float) mc.field_1724.method_19538().method_1022(crystal.method_19538());
            if (dist > range) continue;
            class_2338 cPos = crystal.method_24515();
            boolean valid = mc.field_1687.method_8320(cPos.method_10074()).method_26204() == class_2246.field_10540 || mc.field_1687.method_8320(cPos.method_10074()).method_26204() == class_2246.field_9987;
            if (!valid) continue;
            float score = 10.0f - dist;
            if (score > bestScore) { bestScore = score; bestCrystal = crystal; }
        }
        if (bestCrystal != null) {
            class_243 eye = mc.field_1724.method_33571();
            class_243 cPos = bestCrystal.method_19538();
            double dx = cPos.field_1352 - eye.field_1352; double dy = cPos.field_1351 + 0.5 - eye.field_1351; double dz = cPos.field_1350 - eye.field_1350;
            mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-dx, dz)));
            mc.field_1724.method_36457((float) Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
            mc.field_1761.method_2918(mc.field_1724, bestCrystal);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private void tickSelfTrap(class_310 mc, Module m) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        class_2338 headPos = mc.field_1724.method_24515().method_10084();
        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11036 || dir == class_2350.field_11033) continue;
            class_2338 target = headPos.method_10093(dir);
            if (mc.field_1687.method_8320(target).method_45474()) {
                if (mc.field_1724.method_6047().method_7909() == class_1802.field_8281 || mc.field_1724.method_6079().method_7909() == class_1802.field_8281) {
                    class_2350 placeDir = getPlaceSide(mc, target);
                    if (placeDir != null) {
                        class_2338 neighbor = target.method_10093(placeDir);
                        class_243 hitVec = class_243.method_24953(target).method_1019(new class_243(placeDir.method_23955().mul(-0.5f)));
                        class_3965 hit = new class_3965(hitVec, placeDir, neighbor, false);
                        class_1268 hand = mc.field_1724.method_6047().method_7909() == class_1802.field_8281 ? class_1268.field_5808 : class_1268.field_5810;
                        mc.field_1761.method_2896(mc.field_1724, hand, hit);
                        mc.field_1724.method_6104(hand);
                    }
                }
            }
        }
    }

    private void tickSurround(class_310 mc, Module m) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        class_2338 playerPos = mc.field_1724.method_24515();
        List<class_2338> targets = new ArrayList<>();
        targets.add(playerPos.method_10095()); targets.add(playerPos.method_10072());
        targets.add(playerPos.method_10078()); targets.add(playerPos.method_10067());
        for (class_2338 target : targets) {
            if (mc.field_1687.method_8320(target).method_45474()) {
                if (mc.field_1724.method_6047().method_7909() == class_1802.field_8281 || mc.field_1724.method_6079().method_7909() == class_1802.field_8281) {
                    class_2350 placeDir = getPlaceSide(mc, target);
                    if (placeDir != null) {
                        class_2338 neighbor = target.method_10093(placeDir);
                        class_243 hitVec = class_243.method_24953(target).method_1019(new class_243(placeDir.method_23955().mul(-0.5f)));
                        class_3965 hit = new class_3965(hitVec, placeDir, neighbor, false);
                        class_1268 hand = mc.field_1724.method_6047().method_7909() == class_1802.field_8281 ? class_1268.field_5808 : class_1268.field_5810;
                        mc.field_1761.method_2896(mc.field_1724, hand, hit);
                        mc.field_1724.method_6104(hand);
                    }
                }
            }
        }
    }

    private void applyLuaConfig(Module m, Map<String, Object> config) {
        for (Map.Entry<String, Object> entry : config.entrySet()) {
            dev.stella.executer.gui.setting.Setting setting = m.getSetting(entry.getKey());
            if (setting instanceof dev.stella.executer.gui.setting.SliderSetting s && entry.getValue() instanceof Number n) s.setValue(n.doubleValue());
            else if (setting instanceof dev.stella.executer.gui.setting.BooleanSetting b && entry.getValue() instanceof Boolean v) b.setValue(v);
        }
    }

    public static void updateWorldTableFromPlayer(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        try {
            var globals = dev.stella.executer.brain.LuaScriptHost.getGlobals();
            if (globals == null) return;
            LuaValue worldTable = globals.get("world");
            if (!worldTable.istable()) return;
            LuaTable wt = worldTable.checktable();
            wt.set("x", LuaValue.valueOf(mc.field_1724.method_23317()));
            wt.set("y", LuaValue.valueOf(mc.field_1724.method_23318()));
            wt.set("z", LuaValue.valueOf(mc.field_1724.method_23321()));
            wt.set("health", LuaValue.valueOf(mc.field_1724.method_6032()));
            wt.set("armor", LuaValue.valueOf(mc.field_1724.method_6096()));
            wt.set("onGround", LuaValue.valueOf(mc.field_1724.method_24828()));
            wt.set("inWater", LuaValue.valueOf(mc.field_1724.method_5816()));
            wt.set("yaw", LuaValue.valueOf(mc.field_1724.method_36454()));
            wt.set("pitch", LuaValue.valueOf(mc.field_1724.method_36455()));
        } catch (Exception e) {}
    }

    public static void applyLuaModules(Set<String> enabledModules, Map<String, Map<String, Object>> moduleConfigs) {
        for (String moduleName : enabledModules) {
            Module m = ModuleManager.getInstance().getModule(moduleName);
            if (m != null && !m.isEnabled()) {
                m.setEnabled(true);
            }
        }
        for (Map.Entry<String, Map<String, Object>> entry : moduleConfigs.entrySet()) {
            Module m = ModuleManager.getInstance().getModule(entry.getKey());
            if (m != null) {
                ModuleTicker.getInstance().applyLuaConfig(m, entry.getValue());
            }
        }
    }
}
