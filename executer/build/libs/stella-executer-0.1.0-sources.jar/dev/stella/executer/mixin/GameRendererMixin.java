package dev.stella.executer.mixin;

import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {

    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void onRenderWorld(class_9779 tickCounter, CallbackInfo ci) {
    }

    @Inject(method = "renderWorld", at = @At("RETURN"))
    private void onRenderWorldEnd(class_9779 tickCounter, CallbackInfo ci) {
    }
}
