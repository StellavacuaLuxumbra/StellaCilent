package dev.stella.executer.mixin;

import dev.stella.executer.modules.ModuleTicker;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class ClientConnectionMixin {

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void stella$onSend(class_2596<?> packet, CallbackInfo ci) {
        ModuleTicker.onSendPacket(packet, ci);
    }

    @Inject(method = "channelRead0", at = @At("HEAD"))
    private void stella$onReceive(ChannelHandlerContext context, class_2596<?> packet, CallbackInfo ci) {
        ModuleTicker.onReceivePacket(packet);
    }
}
