package dev.stella.executer.gui.hud;

import dev.stella.executer.gui.render.Render2DUtil;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class FpsHud extends HudElement {

    public FpsHud() {
        super(4, 40);
    }

    @Override
    public void render(class_332 ctx, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1772 == null) return;

        int fps = mc.method_47599();
        String fpsText = "FPS: " + fps;

        int textWidth = mc.field_1772.method_1727(fpsText);
        int bgWidth = textWidth + 10;
        int bgHeight = 12;

        int bgColor = 0xB41E1E1E;
        Render2DUtil.fill(ctx, x, y, x + bgWidth, y + bgHeight, bgColor);

        // color by fps
        int fpsColor;
        if (fps >= 60) fpsColor = 0xFF55FF55;
        else if (fps >= 30) fpsColor = 0xFFFFFF55;
        else fpsColor = 0xFFFF5555;

        ctx.method_25303(mc.field_1772, fpsText, x + 5, y + 2, fpsColor);
    }

    @Override
    public int getWidth() { return 60; }

    @Override
    public int getHeight() { return 12; }
}
