package dev.stella.executer.gui.hud;

import dev.stella.executer.gui.render.ColorUtil;
import dev.stella.executer.gui.render.Render2DUtil;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class WaterMarkHud extends HudElement {

    public WaterMarkHud() {
        super(4, 4);
    }

    @Override
    public void render(class_332 ctx, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1772 == null) return;

        String text = "Stella Client";
        int textWidth = mc.field_1772.method_1727(text);
        int bgWidth = textWidth + 14;
        int bgHeight = 14;

        int bgColor = 0xD20078D4;
        Render2DUtil.drawRoundedRect(ctx, x, y, bgWidth, bgHeight, 4, bgColor);

        ctx.method_25303(mc.field_1772, text, x + 7, y + 3, 0xFFFFFFFF);
    }

    @Override
    public int getWidth() { return 100; }

    @Override
    public int getHeight() { return 14; }
}
