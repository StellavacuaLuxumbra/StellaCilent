package dev.stella.executer.gui.render;

import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import org.joml.Matrix4f;

public class Render2DUtil {

    public static void fill(class_332 ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.method_25294(x1, y1, x2, y2, color);
    }

    public static void fillRect(class_332 ctx, float x, float y, float w, float h, int color) {
        ctx.method_25294((int) x, (int) y, (int) (x + w), (int) (y + h), color);
    }

    public static void drawRoundedRect(class_332 ctx, float x, float y, float w, float h, float radius, int color) {
        float r = Math.min(radius, Math.min(w, h) / 2);
        int a = (color >> 24) & 0xFF;
        int red = (color >> 16) & 0xFF;
        int green = (color >> 8) & 0xFF;
        int blue = color & 0xFF;

        ctx.method_25294((int)(x + r), (int) y, (int)(x + w - r), (int)(y + h), color);
        ctx.method_25294((int) x, (int)(y + r), (int)(x + r), (int)(y + h - r), color);
        ctx.method_25294((int)(x + w - r), (int)(y + r), (int)(x + w), (int)(y + h - r), color);

        Matrix4f matrix = ctx.method_51448().method_23760().method_23761();
        class_289 tess = class_289.method_1348();
        class_287 buf = tess.method_60827(class_293.class_5596.field_27381, class_290.field_1576);

        for (int i = 0; i <= 48; i++) {
            float angle = (float) Math.PI + (float) i / 48 * (float) Math.PI / 2;
            buf.method_22918(matrix, x + r + (float) Math.cos(angle) * r, y + r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        for (int i = 0; i <= 48; i++) {
            float angle = (float) (Math.PI * 1.5) + (float) i / 48 * (float) Math.PI / 2;
            buf.method_22918(matrix, x + w - r + (float) Math.cos(angle) * r, y + r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        for (int i = 0; i <= 48; i++) {
            float angle = (float) i / 48 * (float) Math.PI / 2;
            buf.method_22918(matrix, x + w - r + (float) Math.cos(angle) * r, y + h - r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        for (int i = 0; i <= 48; i++) {
            float angle = (float) (Math.PI / 2) + (float) i / 48 * (float) Math.PI / 2;
            buf.method_22918(matrix, x + r + (float) Math.cos(angle) * r, y + h - r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }

        class_286.method_43433(buf.method_60800());
    }

    public static void drawRoundedStroke(class_332 ctx, float x, float y, float w, float h, float radius, int color, int segments) {
        float r = Math.min(radius, Math.min(w, h) / 2);
        int a = (color >> 24) & 0xFF;
        int red = (color >> 16) & 0xFF;
        int green = (color >> 8) & 0xFF;
        int blue = color & 0xFF;

        Matrix4f matrix = ctx.method_51448().method_23760().method_23761();
        class_289 tess = class_289.method_1348();
        class_287 buf = tess.method_60827(class_293.class_5596.field_29345, class_290.field_1576);

        for (int i = 0; i <= segments; i++) {
            float angle = (float) Math.PI + (float) i / segments * (float) Math.PI / 2;
            buf.method_22918(matrix, x + r + (float) Math.cos(angle) * r, y + r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (Math.PI * 1.5) + (float) i / segments * (float) Math.PI / 2;
            buf.method_22918(matrix, x + w - r + (float) Math.cos(angle) * r, y + r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        for (int i = 0; i <= segments; i++) {
            float angle = (float) i / segments * (float) Math.PI / 2;
            buf.method_22918(matrix, x + w - r + (float) Math.cos(angle) * r, y + h - r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (Math.PI / 2) + (float) i / segments * (float) Math.PI / 2;
            buf.method_22918(matrix, x + r + (float) Math.cos(angle) * r, y + h - r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        float angle0 = (float) Math.PI;
        buf.method_22918(matrix, x + r + (float) Math.cos(angle0) * r, y + r + (float) Math.sin(angle0) * r, 0).method_1336(red, green, blue, a);

        class_286.method_43433(buf.method_60800());
    }

    public static void horizontalGradient(class_332 ctx, int x1, int y1, int x2, int y2, int startColor, int endColor) {
        ctx.method_25296(x1, y1, x2, y2, startColor, endColor);
    }

    public static void verticalGradient(class_332 ctx, int x1, int y1, int x2, int y2, int startColor, int endColor) {
        ctx.method_25296(x1, y1, x2, y2, startColor, endColor);
    }

    public static void drawCircle(class_332 ctx, float cx, float cy, float radius, int color, int segments) {
        int a = (color >> 24) & 0xFF;
        int red = (color >> 16) & 0xFF;
        int green = (color >> 8) & 0xFF;
        int blue = color & 0xFF;

        Matrix4f matrix = ctx.method_51448().method_23760().method_23761();
        class_289 tess = class_289.method_1348();
        class_287 buf = tess.method_60827(class_293.class_5596.field_27381, class_290.field_1576);

        buf.method_22918(matrix, cx, cy, 0).method_1336(red, green, blue, a);
        for (int i = 0; i <= segments; i++) {
            float angle = (float) i / segments * (float) (Math.PI * 2);
            buf.method_22918(matrix, cx + (float) Math.cos(angle) * radius, cy + (float) Math.sin(angle) * radius, 0).method_1336(red, green, blue, a);
        }

        class_286.method_43433(buf.method_60800());
    }

    public static void drawPill(class_332 ctx, float x, float y, float w, float h, int color) {
        float r = h / 2;
        int a = (color >> 24) & 0xFF;
        int red = (color >> 16) & 0xFF;
        int green = (color >> 8) & 0xFF;
        int blue = color & 0xFF;

        ctx.method_25294((int)(x + r), (int) y, (int)(x + w - r), (int)(y + h), color);

        Matrix4f matrix = ctx.method_51448().method_23760().method_23761();
        class_289 tess = class_289.method_1348();

        class_287 buf = tess.method_60827(class_293.class_5596.field_27381, class_290.field_1576);
        buf.method_22918(matrix, x + r, y + r, 0).method_1336(red, green, blue, a);
        for (int i = 0; i <= 64; i++) {
            float angle = (float) i / 64 * (float) (Math.PI * 2);
            buf.method_22918(matrix, x + r + (float) Math.cos(angle) * r, y + r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        class_286.method_43433(buf.method_60800());

        buf = tess.method_60827(class_293.class_5596.field_27381, class_290.field_1576);
        buf.method_22918(matrix, x + w - r, y + r, 0).method_1336(red, green, blue, a);
        for (int i = 0; i <= 64; i++) {
            float angle = (float) i / 64 * (float) (Math.PI * 2);
            buf.method_22918(matrix, x + w - r + (float) Math.cos(angle) * r, y + r + (float) Math.sin(angle) * r, 0).method_1336(red, green, blue, a);
        }
        class_286.method_43433(buf.method_60800());
    }

    public static void drawGlow(class_332 ctx, float x, float y, float w, float h, int color) {
        int red = (color >> 16) & 0xFF;
        int green = (color >> 8) & 0xFF;
        int blue = color & 0xFF;

        Matrix4f matrix = ctx.method_51448().method_23760().method_23761();
        class_289 tess = class_289.method_1348();
        class_287 buf = tess.method_60827(class_293.class_5596.field_27380, class_290.field_1576);

        buf.method_22918(matrix, x, y, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x, y - 10, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x + w, y, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x + w, y - 10, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x + w, y, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x + w + 10, y, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x + w, y + h, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x + w + 10, y + h, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x + w, y + h, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x + w, y + h + 10, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x, y + h, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x, y + h + 10, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x, y + h, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x - 10, y + h, 0).method_1336(red, green, blue, 0);
        buf.method_22918(matrix, x, y, 0).method_1336(red, green, blue, 20);
        buf.method_22918(matrix, x - 10, y, 0).method_1336(red, green, blue, 0);

        class_286.method_43433(buf.method_60800());
    }

    public static void drawLine(class_332 ctx, float x1, float y1, float x2, float y2, int color, float width) {
        int a = (color >> 24) & 0xFF;
        int red = (color >> 16) & 0xFF;
        int green = (color >> 8) & 0xFF;
        int blue = color & 0xFF;

        Matrix4f matrix = ctx.method_51448().method_23760().method_23761();
        class_289 tess = class_289.method_1348();
        class_287 buf = tess.method_60827(class_293.class_5596.field_29344, class_290.field_1576);

        buf.method_22918(matrix, x1, y1, 0).method_1336(red, green, blue, a);
        buf.method_22918(matrix, x2, y2, 0).method_1336(red, green, blue, a);

        class_286.method_43433(buf.method_60800());
    }

    public static boolean isHovered(double mouseX, double mouseY, double x, double y, double w, double h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }
}
