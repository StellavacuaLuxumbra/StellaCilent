package dev.stella.executer.gui.hud;

import dev.stella.executer.gui.render.ColorUtil;
import dev.stella.executer.gui.render.Render2DUtil;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class TargetHud extends HudElement {
    private class_1309 target;

    public TargetHud() {
        super(0, 0);
    }

    @Override
    public void render(class_332 ctx, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1772 == null) return;

        // find nearest target
        target = findTarget(mc);

        int bgW = 120;
        int bgH = 32;
        int bgX = mc.method_22683().method_4486() - bgW - 4;
        int bgY = 40;

        Render2DUtil.fill(ctx, bgX, bgY, bgX + bgW, bgY + bgH, 0xB41E1E1E);

        if (target != null && target.method_5805()) {
            String name = target.method_5477().getString();
            float health = target.method_6032();
            float maxHealth = target.method_6063();
            int armor = target.method_6096();

            ctx.method_25303(mc.field_1772, name, bgX + 4, bgY + 3, 0xFFFFFFFF);

            // health bar
            int barW = bgW - 8;
            float healthPct = Math.min(1.0f, health / maxHealth);
            int barColor = healthPct > 0.5f ? 0xFF55FF55 : healthPct > 0.25f ? 0xFFFFFF55 : 0xFFFF5555;
            ctx.method_25294(bgX + 4, bgY + 13, bgX + 4 + barW, bgY + 16, 0xFF333333);
            ctx.method_25294(bgX + 4, bgY + 13, bgX + 4 + (int)(barW * healthPct), bgY + 16, barColor);

            String info = String.format("HP: %.0f/%.0f  Armor: %d", health, maxHealth, armor);
            ctx.method_25303(mc.field_1772, info, bgX + 4, bgY + 20, 0xFFAAAAAA);
        } else {
            ctx.method_25300(mc.field_1772, "No Target", bgX + bgW / 2, bgY + 12, 0xFF888888);
        }
    }

    private class_1309 findTarget(class_310 mc) {
        double bestDist = 6.0; // max range
        class_1309 best = null;
        class_238 box = mc.field_1724.method_5829().method_1009(6, 6, 6);
        for (class_1309 e : mc.field_1687.method_8390(class_1309.class, box,
                entity -> entity != mc.field_1724 && entity.method_5805() && !entity.method_31481())) {
            double dist = mc.field_1724.method_5739(e);
            if (dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        return best;
    }

    @Override
    public int getWidth() { return 120; }

    @Override
    public int getHeight() { return 32; }
}
