package dev.stella.executer.gui.hud;

import dev.stella.executer.gui.render.Render2DUtil;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class CoordsHud extends HudElement {

    public CoordsHud() {
        super(4, 4);
    }

    @Override
    public void render(class_332 ctx, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1772 == null) return;

        double px = mc.field_1724.method_23317();
        double py = mc.field_1724.method_23318();
        double pz = mc.field_1724.method_23321();
        String coords = String.format("XYZ: %.1f / %.1f / %.1f", px, py, pz);
        String block = String.format("Block: %d / %d / %d", (int) px, (int) py, (int) pz);
        String facing = mc.field_1724.method_5735().method_10151().toUpperCase();

        // nether/overworld conversion
        String dimInfo = "";
        if (mc.field_1687 != null) {
            if (mc.field_1687.method_27983().method_29177().method_12832().equals("the_nether")) {
                dimInfo = String.format("Overworld: %.1f / %.1f / %.1f", px * 8, py, pz * 8);
            } else if (mc.field_1687.method_27983().method_29177().method_12832().equals("overworld")) {
                dimInfo = String.format("Nether: %.1f / %.1f / %.1f", px / 8, py, pz / 8);
            }
        }

        int textWidth = mc.field_1772.method_1727(coords);
        int textWidth2 = mc.field_1772.method_1727(block);
        int textWidth3 = mc.field_1772.method_1727("Facing: " + facing);
        int textWidth4 = dimInfo.isEmpty() ? 0 : mc.field_1772.method_1727(dimInfo);
        int maxW = Math.max(Math.max(textWidth, textWidth2), Math.max(textWidth3, textWidth4));
        int bgWidth = maxW + 10;
        int bgHeight = dimInfo.isEmpty() ? 30 : 40;

        int bgColor = 0xB41E1E1E;
        Render2DUtil.fill(ctx, x, y, x + bgWidth, y + bgHeight, bgColor);

        ctx.method_25303(mc.field_1772, coords, x + 5, y + 3, 0xFFDCDCDC);
        ctx.method_25303(mc.field_1772, block, x + 5, y + 13, 0xFFAAAAAA);
        ctx.method_25303(mc.field_1772, "Facing: " + facing, x + 5, y + 23, 0xFF888888);
        if (!dimInfo.isEmpty()) {
            ctx.method_25303(mc.field_1772, dimInfo, x + 5, y + 33, 0xFF6688AA);
        }
    }

    @Override
    public int getWidth() { return 120; }

    @Override
    public int getHeight() { return 40; }
}
