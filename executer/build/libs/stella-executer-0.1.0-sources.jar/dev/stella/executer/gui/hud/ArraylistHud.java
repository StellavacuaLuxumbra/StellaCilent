package dev.stella.executer.gui.hud;

import dev.stella.executer.gui.render.ColorUtil;
import dev.stella.executer.gui.render.Render2DUtil;
import dev.stella.executer.gui.Module;
import dev.stella.executer.gui.ModuleManager;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ArraylistHud extends HudElement {

    public ArraylistHud() {
        super(0, 10);
    }

    @Override
    public void render(class_332 ctx, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1772 == null) return;

        List<Module> enabled = new ArrayList<>();
        for (Module m : ModuleManager.getInstance().getModules()) {
            if (m.isEnabled()) enabled.add(m);
        }

        // sort by name width descending
        enabled.sort(Comparator.comparingInt((Module m) -> mc.field_1772.method_1727(m.getName())).reversed());

        int screenWidth = mc.method_22683().method_4486();
        int yOff = y;

        for (int i = 0; i < enabled.size(); i++) {
            Module mod = enabled.get(i);
            String name = mod.getName();
            int textWidth = mc.field_1772.method_1727(name);
            int boxWidth = textWidth + 8;
            int boxHeight = 12;

            int bgColor = ColorUtil.injectAlpha(0x1E1E1E, 180);
            int accentColor = ColorUtil.pulseColor(0x0078D4, i, Math.max(1, enabled.size()), 1.0f);

            // background
            int bx = screenWidth - boxWidth;
            Render2DUtil.fillRect(ctx, bx, yOff, boxWidth, boxHeight, bgColor);

            // accent bar
            ctx.method_25294(bx, yOff, bx + 2, yOff + boxHeight, accentColor);

            // text
            ctx.method_25303(mc.field_1772, name, bx + 5, yOff + 2, 0xFFFFFFFF);

            yOff += boxHeight + 1;
        }
    }

    @Override
    public int getWidth() { return 100; }

    @Override
    public int getHeight() { return 12; }
}
