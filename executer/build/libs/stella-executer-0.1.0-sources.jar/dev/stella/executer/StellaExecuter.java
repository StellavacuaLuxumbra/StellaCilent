package dev.stella.executer;

import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dev.stella.executer.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;

public class StellaExecuter implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("Stella");
    private static class_304 openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.stella.clickgui",
                GLFW.GLFW_KEY_G,
                "category.stella"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(ClickGuiScreen.getInstance());
                } else if (client.field_1755 instanceof ClickGuiScreen) {
                    client.field_1755.method_25419();
                }
            }

            if (client.field_1687 != null && client.field_1724 != null) {
                dev.stella.executer.modules.ModuleTicker.getInstance().tick(client);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            dev.stella.executer.gui.hud.HudManager.getInstance().renderAll(drawContext, tickCounter.method_60637(false));
        });

        ClientSendMessageEvents.ALLOW_CHAT.register((message) -> {
            if (dev.stella.executer.command.CommandManager.getInstance().process(message)) {
                return false;
            }
            return true;
        });

        LOGGER.info("Stella driver initialized (pure Java)");
    }
}
