package dev.stella.executer.ipc;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2797;
import net.minecraft.class_310;
import net.minecraft.class_3965;

/**
 * Decodes and executes instruction sequences sent from the C++ Lua brain.
 * Each instruction is: [opcode:u8] [operands...]
 */
public final class InstructionDecoder {
    private InstructionDecoder() {}

    public static void execute(byte[] payload) {
        if (payload.length < 2) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        int count = (payload[0] & 0xFF) | ((payload[1] & 0xFF) << 8);
        int offset = 2;

        for (int i = 0; i < count && offset < payload.length; i++) {
            offset = executeOne(payload, offset, mc);
        }
    }

    private static int executeOne(byte[] p, int off, class_310 mc) {
        if (off >= p.length) return off;
        int opcode = p[off] & 0xFF;
        off++;

        switch (opcode) {
            case Protocol.INST_NOP -> {}

            case Protocol.INST_ATTACK -> {
                if (off + 4 > p.length) return p.length;
                int entityId = readInt(p, off); off += 4;
                class_1297 target = mc.field_1687.method_8469(entityId);
                if (target != null) {
                    mc.field_1761.method_2918(mc.field_1724, target);
                    mc.field_1724.method_6104(class_1268.field_5808);
                }
            }

            case Protocol.INST_PLACE -> {
                if (off + 13 > p.length) return p.length;
                int x = readInt(p, off); off += 4;
                int y = readInt(p, off); off += 4;
                int z = readInt(p, off); off += 4;
                int face = p[off] & 0xFF; off++;
                class_2338 pos = new class_2338(x, y, z);
                class_2350 dir = class_2350.values()[MathHelper_clamp(face, 0, 5)];
                class_243 hitVec = class_243.method_24953(pos).method_1031(
                        dir.method_23955().mul(0.5f).x(),
                        dir.method_23955().mul(0.5f).y(),
                        dir.method_23955().mul(0.5f).z());
                class_3965 hit = new class_3965(hitVec, dir, pos, false);
                mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
                mc.field_1724.method_6104(class_1268.field_5808);
            }

            case Protocol.INST_BREAK -> {
                if (off + 12 > p.length) return p.length;
                int x = readInt(p, off); off += 4;
                int y = readInt(p, off); off += 4;
                int z = readInt(p, off); off += 4;
                mc.field_1761.method_2910(new class_2338(x, y, z), class_2350.field_11036);
            }

            case Protocol.INST_LOOK_AT -> {
                if (off + 24 > p.length) return p.length;
                double tx = readDouble(p, off); off += 8;
                double ty = readDouble(p, off); off += 8;
                double tz = readDouble(p, off); off += 8;
                class_243 eye = mc.field_1724.method_33571();
                double dx = tx - eye.field_1352;
                double dy = ty - eye.field_1351;
                double dz = tz - eye.field_1350;
                mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-dx, dz)));
                mc.field_1724.method_36457((float) Math.toDegrees(-Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
            }

            case Protocol.INST_SWING -> {
                if (off + 1 > p.length) return p.length;
                int hand = p[off] & 0xFF; off++;
                mc.field_1724.method_6104(hand == 1 ? class_1268.field_5810 : class_1268.field_5808);
            }

            case Protocol.INST_SET_SLOT -> {
                if (off + 1 > p.length) return p.length;
                int slot = p[off] & 0xFF; off++;
                mc.field_1724.method_31548().field_7545 = MathHelper_clamp(slot, 0, 8);
            }

            case Protocol.INST_SNEAK -> {
                if (off + 1 > p.length) return p.length;
                mc.field_1724.method_5660(p[off] != 0); off++;
            }

            case Protocol.INST_SPRINT -> {
                if (off + 1 > p.length) return p.length;
                mc.field_1724.method_5728(p[off] != 0); off++;
            }

            case Protocol.INST_VELOCITY -> {
                if (off + 12 > p.length) return p.length;
                float vx = readFloat(p, off); off += 4;
                float vy = readFloat(p, off); off += 4;
                float vz = readFloat(p, off); off += 4;
                mc.field_1724.method_18800(vx, vy, vz);
            }

            case Protocol.INST_USE_ITEM -> {
                mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                mc.field_1724.method_6104(class_1268.field_5808);
            }

            case Protocol.INST_GAMMA -> {
                if (off + 4 > p.length) return p.length;
                float val = readFloat(p, off); off += 4;
                mc.field_1690.method_42473().method_41748(Math.max(0.0, Math.min((double) val, 1.0)));
            }

            case Protocol.INST_CHAT -> {
                if (off >= p.length) return p.length;
                int len = p[off] & 0xFF; off++;
                if (off + len > p.length) return p.length;
                String text = new String(p, off, len, StandardCharsets.UTF_8);
                off += len;
                mc.field_1724.field_3944.method_52787(
                        new class_2797(text, Instant.now(), 0L, null, null));
            }

            case Protocol.INST_STOP_ALL -> {
                mc.field_1724.method_5660(false);
                mc.field_1724.method_5728(false);
            }

            default -> {}
        }
        return off;
    }

    // --- helpers ---
    private static int readInt(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8)
                | ((b[off + 2] & 0xFF) << 16) | ((b[off + 3] & 0xFF) << 24);
    }
    private static float readFloat(byte[] b, int off) {
        return Float.intBitsToFloat(readInt(b, off));
    }
    private static double readDouble(byte[] b, int off) {
        long lo = 0;
        for (int i = 0; i < 8; i++) lo |= ((long) (b[off + i] & 0xFF)) << (8 * i);
        return Double.longBitsToDouble(lo);
    }
    private static int MathHelper_clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
