package dev.stella.executer.ipc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.BitSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_310;
import net.minecraft.class_7923;

/**
 * Serializes the full game state into a binary snapshot.
 * Uses chunk section iteration + filler block filtering for speed.
 *
 * New compact block encoding (section-grouped):
 *   [BLOCKS HEADER]
 *     sectionCount:  u16
 *   Per section:
 *     chunkX:  i16
 *     sectionY: i16
 *     blockCount: u16
 *   Per block in section:
 *     localPos:  u16  (x<<8 | z<<4 | y)  (each 0-15)
 *     blockId:   i16
 */
public final class WorldSnapshot {
    private WorldSnapshot() {}

    // Filler blocks to skip (stone, dirt, etc.) — massive data reduction
    private static final Set<Integer> FILLER_BLOCKS = new HashSet<>();
    static {
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10340));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_28888));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10566));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10219));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10253));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10520));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10515));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10471));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10102));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10534));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10255));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10415));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10115));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10508));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10474));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_27165));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_28049));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_27114));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10360));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10445));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_9989));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10136));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10454));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10056));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10416));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10065));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_37556));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_37557));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10225));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_10491));
        FILLER_BLOCKS.add(class_7923.field_41175.method_10206(class_2246.field_27879));
    }

    private static boolean isFiller(int rawId) {
        return FILLER_BLOCKS.contains(rawId);
    }

    public static byte[] serialize(class_310 mc) {
        if (mc.field_1724 == null || mc.field_1687 == null) return new byte[0];

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream(131072);

            // --- dynamic range from render distance ---
            int renderChunks = mc.field_1690.method_38521();
            int blockRadiusXZ = renderChunks * 16;
            int blockRadiusY = 32; // ±32 blocks vertical (2 sections up, 2 down + partial)

            float scanRange = Math.max(blockRadiusXZ, 64.0f);
            class_238 scanBox = mc.field_1724.method_5829().method_1014(scanRange);

            List<class_1309> entities = mc.field_1687.method_8390(class_1309.class, scanBox,
                    e -> e != mc.field_1724 && e.method_5805() && !e.method_31481());

            List<class_1511> crystals = mc.field_1687.method_8390(class_1511.class, scanBox,
                    e -> e.method_5805() && !e.method_31481());

            // --- chunk-section-based block scan ---
            class_2338 playerPos = mc.field_1724.method_24515();
            int playerChunkX = playerPos.method_10263() >> 4;
            int playerChunkZ = playerPos.method_10260() >> 4;
            int chunkRadiusXZ = (blockRadiusXZ + 15) >> 4;

            ByteArrayOutputStream sectionBuf = new ByteArrayOutputStream(131072);
            int sectionCount = 0;

            for (int cx = -chunkRadiusXZ; cx <= chunkRadiusXZ; cx++) {
                for (int cz = -chunkRadiusXZ; cz <= chunkRadiusXZ; cz++) {
                    class_2818 chunk = mc.field_1687.method_8497(playerChunkX + cx, playerChunkZ + cz);
                    class_2826[] sections = chunk.method_12006();
                    int chunkBaseY = chunk.method_32891();
                    int chunkWorldX = chunk.method_12004().field_9181 * 16;
                    int chunkWorldZ = chunk.method_12004().field_9180 * 16;

                    for (int si = 0; si < sections.length; si++) {
                        class_2826 section = sections[si];
                        if (section.method_38292()) continue;

                        int sectionWorldY = (chunkBaseY + si) * 16;
                        int secTop = sectionWorldY + 16;
                        int secBot = sectionWorldY;
                        int scanTop = playerPos.method_10264() + blockRadiusY;
                        int scanBot = playerPos.method_10264() - blockRadiusY;
                        if (secBot > scanTop || secTop < scanBot) continue;

                        // Collect non-air, non-filler blocks for this section
                        ByteArrayOutputStream blockBuf = new ByteArrayOutputStream(512);
                        int blockInSection = 0;

                        for (int lx = 0; lx < 16; lx++) {
                            int bx = chunkWorldX + lx;
                            if (Math.abs(bx - playerPos.method_10263()) > blockRadiusXZ) continue;

                            for (int lz = 0; lz < 16; lz++) {
                                int bz = chunkWorldZ + lz;
                                if (Math.abs(bz - playerPos.method_10260()) > blockRadiusXZ) continue;

                                int minLocalY = 0, maxLocalY = 16;
                                if (secBot < scanBot) minLocalY = Math.max(0, scanBot - sectionWorldY);
                                if (secTop > scanTop) maxLocalY = Math.min(16, scanTop - sectionWorldY);

                                for (int ly = minLocalY; ly < maxLocalY; ly++) {
                                    class_2680 state = section.method_12254(lx, ly, lz);
                                    if (state.method_26215()) continue;
                                    int rawId = class_7923.field_41175.method_10206(state.method_26204());
                                    if (isFiller(rawId)) continue;

                                    // Compact: localPos = (x<<8 | z<<4 | y), blockId = i16
                                    int localPos = (lx << 8) | (lz << 4) | ly;
                                    writeShort(blockBuf, localPos);
                                    writeShort(blockBuf, rawId);
                                    blockInSection++;
                                }
                            }
                        }

                        if (blockInSection > 0) {
                            // Section header: chunkX(i16) + chunkZ(i16) + sectionY(i16) + blockCount(u16)
                            writeShort(sectionBuf, chunk.method_12004().field_9181);
                            writeShort(sectionBuf, chunk.method_12004().field_9180);
                            writeShort(sectionBuf, chunkBaseY + si);
                            writeShort(sectionBuf, blockInSection);
                            sectionBuf.write(blockBuf.toByteArray(), 0, blockBuf.size());
                            sectionCount++;
                        }
                    }
                }
            }

            // --- header ---
            writeLong(baos, mc.field_1687.method_8510());
            baos.write(1); // playerCount
            writeShort(baos, entities.size());
            writeShort(baos, crystals.size());
            writeShort(baos, sectionCount);

            // --- player ---
            writeInt(baos, mc.field_1724.method_5628());
            writeDouble(baos, mc.field_1724.method_23317());
            writeDouble(baos, mc.field_1724.method_23318());
            writeDouble(baos, mc.field_1724.method_23321());
            writeFloat(baos, mc.field_1724.method_36455());
            writeFloat(baos, mc.field_1724.method_36454());
            writeFloat(baos, mc.field_1724.method_6032());
            writeFloat(baos, mc.field_1724.method_6096());
            baos.write(mc.field_1724.method_24828() ? 1 : 0);
            baos.write(mc.field_1724.method_5624() ? 1 : 0);
            baos.write(mc.field_1724.method_5715() ? 1 : 0);
            writeFloat(baos, mc.field_1724.field_6017);
            writeFloat(baos, (float) mc.field_1724.method_18798().field_1352);
            writeFloat(baos, (float) mc.field_1724.method_18798().field_1351);
            writeFloat(baos, (float) mc.field_1724.method_18798().field_1350);
            writeInt(baos, mc.field_1724.method_6047().method_7960() ? -1 :
                    class_7923.field_41178.method_10206(mc.field_1724.method_6047().method_7909()));
            writeInt(baos, mc.field_1724.method_6079().method_7960() ? -1 :
                    class_7923.field_41178.method_10206(mc.field_1724.method_6079().method_7909()));
            baos.write(mc.field_1724.method_31548().field_7545);

            // --- entities ---
            for (class_1309 e : entities) {
                writeInt(baos, e.method_5628());
                writeShort(baos, class_7923.field_41177.method_10206(e.method_5864()));
                writeFloat(baos, (float) e.method_23317());
                writeFloat(baos, (float) e.method_23318());
                writeFloat(baos, (float) e.method_23321());
                writeFloat(baos, e.method_6032());
                writeFloat(baos, (float) e.method_18798().field_1352);
                writeFloat(baos, (float) e.method_18798().field_1351);
                writeFloat(baos, (float) e.method_18798().field_1350);
                baos.write(e instanceof class_1657 ? 1 : 0);
            }

            // --- crystals ---
            for (class_1511 c : crystals) {
                writeInt(baos, c.method_5628());
                writeFloat(baos, (float) c.method_23317());
                writeFloat(baos, (float) c.method_23318());
                writeFloat(baos, (float) c.method_23321());
                class_2338 cb = c.method_24515();
                var baseState = mc.field_1687.method_8320(cb.method_10074());
                byte baseType = 0;
                if (baseState.method_26204() == class_2246.field_10540) baseType = 1;
                else if (baseState.method_26204() == class_2246.field_9987) baseType = 2;
                baos.write(baseType);
            }

            // --- sections (grouped block data) ---
            sectionBuf.writeTo(baos);

            return baos.toByteArray();
        } catch (IOException e) {
            return new byte[0];
        }
    }

    private static void writeInt(ByteArrayOutputStream s, int v) {
        s.write(v); s.write(v >>> 8); s.write(v >>> 16); s.write(v >>> 24);
    }
    private static void writeLong(ByteArrayOutputStream s, long v) {
        for (int i = 0; i < 8; i++) s.write((int) (v >>> (8 * i)));
    }
    private static void writeFloat(ByteArrayOutputStream s, float v) {
        writeInt(s, Float.floatToRawIntBits(v));
    }
    private static void writeDouble(ByteArrayOutputStream s, double v) {
        writeLong(s, Double.doubleToRawLongBits(v));
    }
    private static void writeShort(ByteArrayOutputStream s, int v) {
        s.write(v); s.write(v >>> 8);
    }
}
