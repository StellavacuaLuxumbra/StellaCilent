package dev.stella.executer.command;

import net.minecraft.class_310;

public interface Command {
    String getName();
    String getDescription();
    String getUsage();
    void execute(String[] args, class_310 mc);
}
